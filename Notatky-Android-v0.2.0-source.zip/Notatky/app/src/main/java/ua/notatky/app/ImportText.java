package ua.notatky.app;
import java.io.*;import java.nio.*;import java.nio.charset.*;import java.util.*;import java.util.regex.Pattern;import java.util.zip.*;
/** Pure Java text decoding and bounded archive processing. */
public final class ImportText {
 public static final int MAX_FILE=16*1024*1024, MAX_TOTAL=64*1024*1024, MAX_ENTRIES=10000;
 public static byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(n>max-out.size())throw new IOException("Size limit");out.write(b,0,n);}return out.toByteArray();}
 static String strict(byte[] b,int offset,Charset c)throws CharacterCodingException{return c.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b,offset,b.length-offset)).toString();}
 public static String decode(byte[] b,String encoding)throws CharacterCodingException{
  if(b.length>=3&&(b[0]&255)==239&&(b[1]&255)==187&&(b[2]&255)==191)return strict(b,3,StandardCharsets.UTF_8);
  if(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==254)return strict(b,2,StandardCharsets.UTF_16LE);
  if(b.length>=2&&(b[0]&255)==254&&(b[1]&255)==255)return strict(b,2,StandardCharsets.UTF_16BE);
  if(!encoding.equals("auto"))return strict(b,0,Charset.forName(encoding));
  int even=0,odd=0;for(int i=0;i<b.length;i++)if(b[i]==0){if(i%2==0)even++;else odd++;}
  if(b.length>=4&&b.length%2==0){if(odd>b.length/8&&even==0)return strict(b,0,StandardCharsets.UTF_16LE);if(even>b.length/8&&odd==0)return strict(b,0,StandardCharsets.UTF_16BE);}
  try{return strict(b,0,StandardCharsets.UTF_8);}catch(CharacterCodingException e){return strict(b,0,Charset.forName("windows-1251"));}
 }
 /** Only an explicit ISO-8601 creation header, never an inferred date. */
 public static long created(String body){int end=body.indexOf('\n');String line=(end<0?body:body.substring(0,end)).trim();if(!line.startsWith("Created: "))return 0;try{return java.time.OffsetDateTime.parse(line.substring(9).trim()).toInstant().toEpochMilli();}catch(java.time.DateTimeException ex){return 0;}}
 public static String[] split(String s,String delimiter){return delimiter.isEmpty()?new String[]{s}:s.split(Pattern.quote(delimiter),-1);}
 public static boolean txt(String n){return n.toLowerCase(Locale.ROOT).endsWith(".txt");}
 public static String title(String n){n=n.replace('\\','/');n=n.substring(n.lastIndexOf('/')+1);return txt(n)?n.substring(0,n.length()-4):n;}
 public static final class Archive { public final List<Entry> files=new ArrayList<>();public int skipped; }
 public record Entry(String name,long modified,byte[] bytes){}
 public static Archive zip(InputStream stream,java.util.function.BooleanSupplier cancelled)throws IOException{
  Archive a=new Archive();int count=0,total=0;try(ZipInputStream z=new ZipInputStream(stream)){ZipEntry e;while((e=z.getNextEntry())!=null){if(cancelled.getAsBoolean())throw new InterruptedIOException();if(++count>MAX_ENTRIES)throw new IOException("Entry limit");if(e.isDirectory()){z.closeEntry();continue;}byte[] b=read(z,Math.min(MAX_FILE,MAX_TOTAL-total));total+=b.length;if(txt(e.getName()))a.files.add(new Entry(e.getName(),e.getTime(),b));else a.skipped++;z.closeEntry();}}if(count==0)throw new IOException("Empty or invalid ZIP");return a;
 }
}
