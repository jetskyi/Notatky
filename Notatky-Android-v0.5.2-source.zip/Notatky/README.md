# Версія 0.3.0 — перероблений інтерфейс

За відеореференсом: графітовий фон, компактні картки з повною датою, заголовки місяців, плаваюча кнопка, бічне меню, окремі режими читання й редагування, заголовок нотатки, швидкі дії та папки. Попередні функції залишені у вихідному коді. Папки — назви, що присвоюються нотаткам; порожні папки окремо не зберігаються. Зірочки використовують попереднє поле закріплення. Undo/redo охоплює текст нотатки (до 30 знімків, попередні тексти до 100000 символів), а не заголовок.

SQLite v3 додає колонку folder, резервні копії версій 1–3 підтримуються новою версією. Перед оновленням експортуйте JSON: GitHub Actions може створити APK з іншим debug-ключем, тоді Android не дозволить встановити його поверх старого. Не видаляйте стару версію без перевіреної резервної копії.

Тести: 6 тестів пошуку, 15 тестів логіки імпорту, синтаксичний парсинг Java, перевірка XML та 128 ключів кожної мови, SQL-міграція v2→v3, призначення папки та захист порожньої чернетки з нагадуванням. Android SDK у середовищі відсутній; нова версія ще не скомпільована і не запущена на смартфоні.

---

Попередня документація нижче (історична версія).

# Нотатки — вихідний проєкт 0.1.0

Нативний Android, Java, SQLite. Android 8+ (API 26), compile SDK 35, target 34. Без мережевих дозволів і сторонніх бібліотек. Це вихідна версія для першої збірки, НЕ перевірений APK.

## Збірка Windows
1. Встановіть Android Studio з офіційного сайту https://developer.android.com/studio .
2. Розпакуйте архів і відкрийте папку Notatky як проєкт. В SDK Manager встановіть Android SDK Platform 35 і Build Tools 35.0.0. Використовуйте JDK 17 і Gradle 8.9 (можна встановити локально та вибрати в налаштуваннях Gradle Android Studio; wrapper не включено).
3. Дочекайтесь Gradle Sync. Build > Build App Bundle(s) / APK(s) > Build APK(s), або в терміналі `gradle :app:assembleDebug`.
4. Файл app/build/outputs/apk/debug/app-debug.apk перенесіть на телефон, дозвольте встановлення з цього джерела та відкрийте файл. Для постійних оновлень зберігайте той самий ключ підпису та applicationId. Debug APK не призначено для релізу.
5. У застосунку дозвольте сповіщення та (за потреби) точні нагадування. Якщо точний дозвіл відсутній, Android може затримати сповіщення. Після примусової зупинки системою нагадування не гарантовано працюють до повторного запуску.

Також додано GitHub Actions workflow для першої збірки у власному репозиторії. Він не запускався тут. Не завантажуйте до репозиторію приватні нотатки або ключі.

## Дані
JSON містить усі нотатки, кошик, нагадування та JPEG-обкладинки у Base64. Відновлення замінює дані транзакційно, тому спершу експортуйте поточну копію. TXT є простим текстом без метаданих; імпорт створює одну нотатку. Резервні файли не шифруються. Дані застосунку захищені стандартною ізоляцією Android, не окремим паролем. Під час видалення застосунку локальна база видаляється. Зміни схеми майбутніх версій потребують явної міграції; поточна версія відмовляється від невідомої міграції замість знищення таблиць.

## Інтеграція
Вхідний ACTION_SEND приймає текст після підтвердження користувачем, вихідний ACTION_SEND дозволяє вручну передати текст. Якщо ChatGPT не пропонує системне меню поширення, скопіюйте текст вручну. Прямого MCP/API сервера, авторизації або синхронізації немає. Майбутній адаптер має використовувати Store, а не відкривати SQLite у мережу: HTTPS, OAuth, окремі read/write scopes, відкликання доступу, журнал змін, підтвердження руйнівних операцій. Не додавайте секрети в APK. Повний custom MCP доступ за поточною документацією доступний організаційним планам; Pro має обмежений read/fetch. https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt

## Аудит та обмеження
- Пройшли JVM тести пошуку (tests/results.txt). Команда: `javac -d out app/src/main/java/ua/notatky/app/Search.java tests/SearchTest.java` та `java -cp out ua.notatky.app.SearchTest`.
- Реалізовано у вихідному коді, але не запускалося: CRUD, кошик, закріплення, автозбереження, календар, групи, пошук у редакторі, обкладинки з кадруванням, JSON/TXT, нагадування та відновлення після boot.
- Частково: нечіткий пошук оцінює рядки, не є повноцінною морфологією; пошук на головному потоці та список без віртуалізації можуть бути повільними у дуже великих базах. SQLite CursorWindow може обмежити дуже великі окремі записи. Повторення інтервальні, не гарантують однаковий місцевий час після зміни літнього часу. Немає окремого статусу скасування, лише завершення. Немає окремого повного набору UI/Android-тестів. Стан редактора під час знищення Activity системою не відновлюється повністю. JSON експорт/імпорт завантажує дані в пам'ять. Фото зберігається лише обрізаним; для нового кадру потрібно вибрати оригінал. Візуальний референс не був прикріплений у поточному повідомленні.
- Не реалізовано: хмарна синхронізація, діючий захищений API/MCP, релізний APK. SDK/Gradle/емулятор відсутні, мережеве завантаження SDK заблоковане. Збірка і робота Android-коду не підтверджені.
- Виправлено під час статичного перегляду: використання новіших Java API readAllBytes/isBlank/List.of, подвійні системні відступи, застаріле підсвічування після редагування. Повторено JVM тести. Ці виправлення не є результатом тестування на Android.

## Перед повсякденним використанням
Перевірте збірку, запуск, поворот екрана, всі меню, великі тексти, 1000+ нотаток з фото, відновлення JSON, спрацювання нагадувань у Doze і після перезавантаження, дозволи, оновлення під тим самим ключем. До завершення цих перевірок не використовуйте програму як єдине сховище важливих даних.

## Версія 0.2.0 — пункти 14–17

- Меню → Налаштування → Мова: українська (типова), російська, англійська. Ресурси Android `values`, `values-ru`, `values-en`; вибір через SharedPreferences, оновлення Activity без ручного перезапуску. Текст нотаток не перекладається. Назви місяців/днів залежать від обраної locale. Дати в частині екранів залишаються у форматі день-місяць-рік; час — 24-годинний. Системні вікна вибору файлів можуть використовувати системну мову. Повнота відображення та граматика у контексті не перевірені на Android.
- Налаштування → Оформлення: системна (типова), темна, світла. Окремі палітри, нативні теми Android, збереження вибору, системні панелі. Перемикання через Activity.recreate; автоматичне реагування на uiMode залежить від стандартного життєвого циклу Android, не перевірено на пристрої.
- Меню → Імпорт TXT: окремі або кілька файлів, папка з рекурсивним обходом, ZIP. Підтримується UTF-8, UTF-16LE/BE, Windows-1251; автоматичне визначення евристичне (особливо UTF-16 без BOM та пошкоджений UTF-8). Якщо текст виглядає неправильно, слід скасувати та вибрати кодування вручну. Роздільник є буквальним рядком; видаляються лише самі роздільники. Порожні частини зберігаються. Назви беруться з імен файлів; явний перший рядок `Created: 2024-11-25T10:30:00+01:00` відновлює дату, залишаючи заголовок метаданих у тексті. Інші формати метаданих не розпізнаються. Час модифікації файлу або ZIP не є часом створення й використовується тільки за вибором користувача. За відсутності дати використовуються вибрані користувачем дата імпорту або ручна дата. Дублікати — точний збіг тексту серед активних нотаток; політика одна для всього імпорту. Заміна зберігає ID, обкладинку та закріплення наявної нотатки. Попередній перегляд показує фрагменти перших 20 нотаток, не всі записи. Підготовка й запис відбуваються в окремому потоці, запис транзакційний. Скасування перевіряється між файлами/нотами; не гарантується миттєва реакція під час читання великого файлу. Поворот екрану під час імпорту не перевірений. Оригінальні файли відкриваються лише для читання.
- Межі безпеки для імпорту: 10 000 записів/файлів, 16 МіБ на файл, 64 МіБ текстових байтів на пакет, 400 000 символів на окрему нотатку для уникнення надмірного розміру SQLite CursorWindow. Великі файли можна розділити буквальним роздільником, якщо вони не перевищують загальної межі. ZIP не розпаковується у файлову систему; підрахунок розпакованих байтів обмежено. Пошкоджені файли та непідтримувані записи враховуються у звіті, проте пошкодження центрального каталогу ZIP та довільні двійкові дані не завжди виявляються. Під час підготовки текст перебуває в пам'яті; навантаження на телефон потрібно виміряти.
- База v2 додає `title` через ALTER TABLE, без очищення таблиць; резервні копії JSON v1 та v2 підтримуються. Назва нотатки редагується в меню та доступна глобальному пошуку. APK versionCode 2.

### Аудит 0.2.0

Фактично виконано: 6 попередніх тестів пошуку, 15 тестів Java логіки імпорту (включно з 2000 записами ZIP), синтаксичний розбір Java, XML, перевірка 114 ключів локалізації та SQLite-тест міграції одного запису. Результати — `tests/results.txt`. Немає Android SDK/Gradle/емулятора, тому збірка, реальна міграція Android SQLite, відображення UI, перемикання мов/тем, SAF, транзакційний масовий імпорт, продуктивність і поведінка на фізичному телефоні не перевірені. Тести чистої Java не є тестами Android. Немає готового APK. Перед використанням з важливими даними потрібні збірка, Android-тести та резервна копія.

Локальні тести без Android SDK (JDK 17+):
```
javac -encoding UTF-8 -d test-out app/src/main/java/ua/notatky/app/Search.java app/src/main/java/ua/notatky/app/ImportText.java tests/SearchTest.java tests/ImportTest.java
java -cp test-out ua.notatky.app.SearchTest
java -cp test-out ua.notatky.app.ImportTest
```

## 0.4.0 — MyNotes import and scrolling
- Select TXT import → Automatic (split dated MyNotes exports). The parser recognizes a date line, a weekday/time line and a dashed divider preceding another valid header. Dates are interpreted in the device time zone; ordinary files without this structure remain separate individual notes. Preview the count before confirming. Existing merged imports are not modified automatically. Reimport from the original file, then move the old merged note to trash only after checking the new notes.
- The home screen uses a virtualized ListView, bounded previews and an asynchronous query; reading no longer automatically opens the editor when touched. Physical-device smoothness is not verified.
- Pure Java tests include 2,000 dated entries, original dates, internal dividers, text preservation, ordinary TXT and explicit single-file mode. Android compilation still requires GitHub Actions.

## 0.4.1 — MyNotes import regression
- Accept Unicode horizontal spaces (including U+00A0 and U+202F), CRLF, blank lines in metadata and an optional MyNotes heading.
- Recognized dated records retain their local timestamps. The specific file MyNotes.txt no longer silently imports an unrecognized export containing separators as a single note in automatic mode.
- A localized diagnostic is included in the import preview if that file cannot be recognized.
- Tests use reconstructed samples, not the user's actual TXT file. Android build and UI verification remain outstanding.

### 0.4.2 — MyNotes import
Validated the exact user-provided export locally: 668 entries, 667 delimiters, all timestamps and exact body hashes independently matched. The original private export and generated backup are deliberately excluded from this source archive. Dated imports now compare both body and original date when detecting duplicates, not just body. MyNotes filenames with numeric download suffixes also receive strict parsing. Android compilation and device import still require verification. A separate JSON restore file, if supplied, replaces all current notes and reminders; back up existing data before restoring it. The TXT did not contain separate last-edited timestamps, so the generated backup uses creation time for edited as a placeholder. Dates are interpreted in Europe/Berlin for that backup; the Android importer uses the phone timezone.


## 0.5.0 — Cover update
- Built-in categorized emoji selector (8 groups, system font glyph filtering); up to ten emoji, adaptive display size. Existing overlong covers are visually capped; saving the picker replaces the legacy value. Exact Samsung Keyboard inventory is not available.
- Photo covers fill the card with a dark readability overlay, separate viewer button, zoom/position crop and replacement. New originals are preserved in local database chunks, with thumbnail caching and background loading. Old images only have the previously saved crop; reselect to restore full image.
- GIF original preserved; animation in full-screen viewer on Android 9+, static first frame on list and Android 8. Images up to 12 MiB. Original preview is downsampled on screen for memory safety.
- Schema 4 adds cover_media and cleanup trigger. JSON backup v4 contains original media; restores v1–v4. Old app versions cannot restore v4. Back up notes before uninstalling any previous debug-signed version.
- No Android SDK in authoring environment: build, image picker, glyph coverage, animations, and scrolling need verification on physical device.

## 0.5.1 — Visible-only animated GIF backgrounds
- Android 9+ uses ImageDecoder/AnimatedImageDrawable for GIF backgrounds, with infinite looping and the existing card shade. Android 8 remains on static thumbnails.
- Animation is eligible only for a card intersecting the current list viewport, attached and shown, in a resumed activity with window focus, no open drawer, and GIF animation enabled. Visibility is checked before drawing; leaving the viewport, detaching, navigating away or pausing stops playback and releases the animated drawable. Re-entering restarts from the beginning. Decode runs on one background worker; cancelled or stale results cannot start an animation. A static thumbnail remains during loading or on decode failure. No network access required.
- Settings → GIF cover animation, enabled by default. Stored in SharedPreferences.
- Schema 5 adds cropZoom/cropX/cropY. Migration preserves existing notes, reminders and original media; old GIF crop values were never stored, so older GIFs use a default centered crop for animation until edited and saved again. New crops and copies persist their parameters. JSON version 5 restores versions 1–5; older app versions cannot restore version 5.
- Android runtime/compile not verified locally. Check several visible GIFs, fast scrolling, menu/notification shade, foreground/background, opening a note, replacing/removing images, migration and backup/restore, and image crop on the actual phone. A corrupt or unsupported animated image falls back to the thumbnail. No measured device RAM or battery results.
- JVM test: `javac -d out app/src/main/java/ua/notatky/app/GifPolicy.java tests/GifPolicyTest.java && java -cp out ua.notatky.app.GifPolicyTest`.

## 0.5.2 — Adaptive cover text contrast
- Cover thumbnails are sampled separately in the left date area and right title/preview area, taking CENTER_CROP geometry and the light/dark card background into account. Dark backgrounds receive light text with a black outline; light backgrounds receive dark text with a white outline. Secondary labels retain a modest tone difference. The outline uses the existing native TextView layout in two drawing passes, with a 1.1dp total stroke and a subtle 0.9dp shadow. Covers use a ~12.5% black shade instead of the previous 60% shade; plain cards keep their original appearance.
- For GIFs, the saved first-frame thumbnail determines the palette; it is not recalculated for every frame. Opposite-colour outlines remain stable as the GIF plays. No per-frame pixel readback or new animation worker. The 0.5.1 visible-only playback policy is unchanged. Image text rendering still needs device verification, especially mixed backgrounds and animated frames.
- Application versionCode 9; SQLite schema and JSON format unchanged (v5).
- Actual tests in `tests/results.txt`: contrast policy, transparent images on both themes, monotonic grayscale classification, 14,544 coordinate cases, existing GIF/cover/search/import regression tests and syntax/XML parsing. Android SDK is unavailable locally, so no APK or physical rendering test here.
