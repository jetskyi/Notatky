package ua.notatky.app;

/** Stable contrast policy for an image thumbnail. No per-animation-frame work. */
final class CoverContrast {
 static final int SHADE_ALPHA=32;
 static final int WHITE=0xfffafafa, LIGHT_SECONDARY=0xffeeeeee;
 static final int BLACK=0xff202020, DARK_SECONDARY=0xff282828;
 static final int WHITE_OUTLINE=0xffFFFFFF, BLACK_OUTLINE=0xff000000;
 static int fill(boolean darkInk,boolean secondary){return darkInk?(secondary?DARK_SECONDARY:BLACK):(secondary?LIGHT_SECONDARY:WHITE);}
 static int outline(boolean darkInk){return darkInk?WHITE_OUTLINE:BLACK_OUTLINE;}
 private static double linear(double s){s/=255;return s<=.04045?s/12.92:Math.pow((s+.055)/1.055,2.4);}
 static double luminance(int argb,int background){
  double alpha=((argb>>>24)&255)/255.0, shade=1-SHADE_ALPHA/255.0;
  double r=(((argb>>>16)&255)*alpha+((background>>>16)&255)*(1-alpha))*shade;
  double g=(((argb>>>8)&255)*alpha+((background>>>8)&255)*(1-alpha))*shade;
  double b=((argb&255)*alpha+(background&255)*(1-alpha))*shade;
  return .2126*linear(r)+.7152*linear(g)+.0722*linear(b);
 }
 static boolean darkInk(int[] pixels,int background){
  if(pixels.length==0)return false;
  double sum=0;for(int pixel:pixels)sum+=luminance(pixel,background);
  // Slightly favour light text on mixed backgrounds; the opposite outline remains on all frames.
  return sum/pixels.length>=.24;
 }
 // Map normalized view coordinates into an ImageView CENTER_CROP source.
 static int coordinate(double fraction,int source,int other,int view,int otherView){
  if(source<=0||other<=0||view<=0||otherView<=0)throw new IllegalArgumentException();
  double scale=Math.max((double)view/source,(double)otherView/other);
  double visible=view/scale;
  return Math.max(0,Math.min(source-1,(int)Math.floor((source-visible)/2+fraction*visible)));
 }
}
