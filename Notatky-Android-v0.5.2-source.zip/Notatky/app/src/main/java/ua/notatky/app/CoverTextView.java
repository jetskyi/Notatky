package ua.notatky.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.widget.TextView;

/** Same native layout, ellipsis and baseline in both drawing passes. */
final class CoverTextView extends TextView {
 private final boolean secondary;
 private final float density;
 private boolean darkInk;
 private ColorFilter outlineFilter;
 CoverTextView(Context c,boolean secondary){
  super(c);this.secondary=secondary;density=getResources().getDisplayMetrics().density;
  applyContrast(false);
 }
 void applyContrast(boolean dark){
  if(outlineFilter!=null&&darkInk==dark)return;
  darkInk=dark;
  outlineFilter=new PorterDuffColorFilter(CoverContrast.outline(dark),PorterDuff.Mode.SRC_IN);
  setTextColor(CoverContrast.fill(dark,secondary));
  invalidate();
 }
 @Override protected void onDraw(Canvas canvas){
  if(outlineFilter==null){super.onDraw(canvas);return;}
  Paint p=getPaint();Paint.Style style=p.getStyle();float width=p.getStrokeWidth();
  Paint.Join join=p.getStrokeJoin();ColorFilter previous=p.getColorFilter();
  // 1.1dp total stroke = about 0.55dp outside glyph; subtle depth, not a heavy border.
  try{
   p.setStyle(Paint.Style.STROKE);p.setStrokeJoin(Paint.Join.ROUND);
   p.setStrokeWidth(1.1f*density);p.setColorFilter(outlineFilter);
   p.setShadowLayer(.9f*density,0,.65f*density,0x33000000);
   super.onDraw(canvas);
  }finally{
   p.clearShadowLayer();p.setColorFilter(previous);p.setStrokeWidth(width);
   p.setStrokeJoin(join);p.setStyle(style);
  }
  super.onDraw(canvas);
 }
}
