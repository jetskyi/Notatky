package ua.notatky.app;

import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.ViewTreeObserver;
import android.view.ViewParent;
import android.widget.ImageView;
import java.nio.ByteBuffer;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

/** One card, one visible-only animation. No persistent animated drawable cache. */
final class GifCoverView extends ImageView {
 final MainActivity a;
 final long noteId;
 private final int zoom,x,y;
 private final Rect visibleRect=new Rect(),listRect=new Rect();
 private final GifPolicy.Request requests=new GifPolicy.Request();
 private final ViewTreeObserver.OnPreDrawListener visibilityCheck=()->{syncPlayback();return true;};
 private ViewTreeObserver observer;
 private Bitmap thumbnail;
 private AnimatedImageDrawable playing;
 private Future<?> pending;
 private boolean failed=false, invalidated=false;

 GifCoverView(MainActivity a,long id,int zoom,int x,int y){
  super(a);this.a=a;noteId=id;this.zoom=GifPolicy.clamp(zoom);this.x=GifPolicy.clamp(x);this.y=GifPolicy.clamp(y);
 }
 void setThumbnail(Bitmap b){thumbnail=b;if(playing==null)setImageBitmap(b);}
 @Override protected void onAttachedToWindow(){
  super.onAttachedToWindow();register();
 }
 @Override protected void onDetachedFromWindow(){
  unregister();super.onDetachedFromWindow();
 }
 private void register(){if(observer!=null)return;a.gifViews.add(this);observer=getViewTreeObserver();observer.addOnPreDrawListener(visibilityCheck);syncPlayback();}
 private void unregister(){if(observer!=null&&observer.isAlive())observer.removeOnPreDrawListener(visibilityCheck);observer=null;a.gifViews.remove(this);stopPlayback();}
 @Override public void onStartTemporaryDetach(){unregister();super.onStartTemporaryDetach();}
 @Override public void onFinishTemporaryDetach(){super.onFinishTemporaryDetach();if(isAttachedToWindow())register();}
 @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(a!=null)syncPlayback();}
 @Override public void onVisibilityAggregated(boolean visible){super.onVisibilityAggregated(visible);if(a!=null)syncPlayback();}
 private boolean visible(){
  if(observer==null||a.homeScroll==null||!a.gifCanPlay())return false;
  ViewParent p=getParent();while(p!=null&&p!=a.homeScroll)p=p.getParent();
  boolean intersects=p==a.homeScroll&&getGlobalVisibleRect(visibleRect)&&a.homeScroll.getGlobalVisibleRect(listRect)&&visibleRect.intersect(listRect);
  return !invalidated&&GifPolicy.shouldPlay(Build.VERSION.SDK_INT>=28,a.gifCanPlay(),hasWindowFocus(),isAttachedToWindow(),isShown()&&getWindowVisibility()==VISIBLE,intersects?visibleRect.width():0,intersects?visibleRect.height():0);
 }
 void invalidateMedia(){invalidated=true;stopPlayback();}
 void syncPlayback(){
  if(!visible()){stopPlayback();failed=false;return;}
  if(playing!=null||pending!=null||failed)return;
  final long token=requests.begin();
  try{pending=a.gifWorker.submit(()->{
   AnimatedImageDrawable animation=null;
   try{
    if(!Thread.currentThread().isInterrupted()){
     byte[] data=a.db.originalCover(noteId);
     if(Covers.gif(data)&&!Thread.currentThread().isInterrupted())animation=decode(data,zoom,x,y);
    }
   }catch(Exception ignored){/* Keep static thumbnail on unsupported/corrupt GIF. */}
   final AnimatedImageDrawable result=animation;
   a.runOnUiThread(()->complete(token,result));
  });}catch(RejectedExecutionException ignored){failed=true;}
 }
 private void complete(long token,AnimatedImageDrawable result){
  if(!requests.valid(token))return;
  pending=null;
  if(!visible()){stopPlayback();return;}
  if(result==null){failed=true;return;}
  playing=result;
  setImageDrawable(result);
  result.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
  result.start();
 }
 private void stopPlayback(){
  if(pending!=null){requests.cancel();pending.cancel(true);a.gifWorker.purge();pending=null;}
  if(playing!=null){playing.stop();playing=null;setImageBitmap(thumbnail);}
 }
 @android.annotation.TargetApi(28)
 private static AnimatedImageDrawable decode(byte[] data,int zoom,int x,int y)throws java.io.IOException{
  Drawable result=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(data)),(decoder,info,src)->{
   int w=info.getSize().getWidth(),h=info.getSize().getHeight();
   float scale=Math.min(1f,768f/Math.max(w,h));
   int sw=Math.max(1,Math.round(w*scale)),sh=Math.max(1,Math.round(h*scale));
   decoder.setTargetSize(sw,sh);
   int[] crop=CoverRules.crop(sw,sh,zoom,x,y);
   decoder.setCrop(new Rect(crop[0],crop[1],crop[0]+crop[2],crop[1]+crop[3]));
  });
  return result instanceof AnimatedImageDrawable?(AnimatedImageDrawable)result:null;
 }
}
