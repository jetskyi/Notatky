package ua.notatky.app;
/** Pure playback policy, also exercised on the JVM. */
final class GifPolicy {
 static boolean shouldPlay(boolean supported, boolean foreground, boolean focused, boolean attached, boolean shown, int width, int height){
  return supported && foreground && focused && attached && shown && width>0 && height>0;
 }
 static int clamp(int value){return Math.max(0,Math.min(100,value));}
 static final class Request {
  private long generation;
  long begin(){return ++generation;}
  void cancel(){generation++;}
  boolean valid(long token){return token==generation;}
 }
}
