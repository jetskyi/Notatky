package ua.notatky.app;
import java.util.Arrays;
public class CoverContrastTest {
 static void check(boolean condition,String label){if(!condition)throw new AssertionError(label);}
 static int gray(int v){return 0xff000000|(v<<16)|(v<<8)|v;}
 public static void main(String[] args){
  int dark=0xff303030,light=0xfff0f0f0;
  check(!CoverContrast.darkInk(new int[]{0xff000000},dark),"black -> light fill");
  check(CoverContrast.darkInk(new int[]{0xffffffff},dark),"white -> dark fill");
  check(!CoverContrast.darkInk(new int[]{0x00000000},dark),"transparent dark theme");
  check(CoverContrast.darkInk(new int[]{0x00000000},light),"transparent light theme");
  check(!CoverContrast.darkInk(new int[0],dark),"missing thumbnail fallback");
  check(CoverContrast.outline(true)==0xffffffff&&CoverContrast.outline(false)==0xff000000,"opposite stroke");
  int changes=0;boolean old=false;for(int v=0;v<256;v++){boolean next=CoverContrast.darkInk(new int[]{gray(v)},dark);if(next!=old)changes++;old=next;}
  check(changes==1,"monotonic grayscale threshold");
  int[] sample=new int[32];Arrays.fill(sample,gray(10));check(!CoverContrast.darkInk(sample,dark),"dark region");Arrays.fill(sample,gray(245));check(CoverContrast.darkInk(sample,dark),"light region");
  int checks=0;for(int s:new int[]{1,3,100,600})for(int o:new int[]{1,3,100,600})for(int v:new int[]{1,50,400})for(int ov:new int[]{1,50,400})for(int f=0;f<=100;f++){
   int c=CoverContrast.coordinate(f/100.0,s,o,v,ov);check(c>=0&&c<s,"crop sample in bounds");checks++;
  }
  check(CoverContrast.coordinate(0,600,200,300,200)==150,"center crop start");
  check(CoverContrast.coordinate(1,600,200,300,200)==450,"center crop end");
  System.out.println("PASS contrast black/white, transparent themes, opposite stroke, grayscale threshold, split regions, "+checks+" sampling bounds");
 }
}
