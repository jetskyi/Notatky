package ua.notatky.app;
public final class GifPolicyTest {
 public static void main(String[] args){
  int tested=0;
  for(int bits=0;bits<32;bits++)for(int w:new int[]{0,1,120})for(int h:new int[]{0,1,68}){
   boolean actual=GifPolicy.shouldPlay((bits&1)!=0,(bits&2)!=0,(bits&4)!=0,(bits&8)!=0,(bits&16)!=0,w,h);
   if(actual!=(bits==31&&w>0&&h>0))throw new AssertionError("visibility policy");tested++;
  }
  GifPolicy.Request r=new GifPolicy.Request();long old=r.begin();if(!r.valid(old))throw new AssertionError();r.cancel();if(r.valid(old))throw new AssertionError("stale decode");long now=r.begin();if(r.valid(old)||!r.valid(now))throw new AssertionError("re-enter viewport");
  for(int i=-100;i<=200;i++){int j=GifPolicy.clamp(i);if(j<0||j>100||(i>=0&&i<=100&&i!=j))throw new AssertionError("crop range");}
  System.out.println("PASS "+tested+" visibility combinations; cancellation/reentry token; 301 crop values");
 }
}
