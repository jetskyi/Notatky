package ua.notatky.app;
public class CoverRulesTest {
 public static void main(String[] args){if(CoverRules.LIMIT!=10||CoverRules.size(3)<=CoverRules.size(4)||CoverRules.size(6)<=CoverRules.size(7))throw new AssertionError();for(int w:new int[]{1,100,512,1920,4096})for(int h:new int[]{1,100,512,1080,4096})for(int z:new int[]{0,50,100})for(int x:new int[]{0,50,100})for(int y:new int[]{0,50,100}){int[] r=CoverRules.crop(w,h,z,x,y);if(r[0]<0||r[1]<0||r[2]<1||r[3]<1||r[0]+r[2]>w||r[1]+r[3]>h)throw new AssertionError();}System.out.println("PASS 675 crop bounds and 10 emoji limit/size rules");}
}
