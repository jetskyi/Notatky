package ua.notatky.app;
final class CoverRules {
 static final int LIMIT=10;
 static int size(int count){return count<=3?22:count<=6?17:14;}
 static int columns(int count){return count<=3?3:5;}
 static int[] crop(int width,int height,int zoom,int x,int y){if(width<1||height<1)throw new IllegalArgumentException();float w=Math.min(width,height*3f)/(1+zoom/33f);int iw=Math.max(1,Math.min(width,Math.round(w))),ih=Math.max(1,Math.min(height,Math.round(w/3f)));return new int[]{(width-iw)*x/100,(height-ih)*y/100,iw,ih};}
}
