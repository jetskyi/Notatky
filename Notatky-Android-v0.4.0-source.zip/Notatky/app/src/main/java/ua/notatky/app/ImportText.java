package ua.notatky.app;
import java.io.*;import java.nio.*;import java.nio.charset.*;import java.util.*;import java.util.regex.Pattern;import java.util.zip.*;
/** Pure Java text decoding and bounded archive processing. */
public final class ImportText {
 public static final int MAX_FILE=16*1024*1024, MAX_TOTAL=64*1024*1024, MAX_ENTRIES=10000;
 public static byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(n>max-out.size())throw new IOException("Size limit");out.write(b,0,n);}return out.toByteArray();}
 static String strict(byte[] b,int offset,Charset c)throws CharacterCodingException{return c.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b,offset,b.length-offset)).toString();}
 public static String decode(byte[] b,String encoding)throws CharacterCodingException{
  if(b.length>=3&&(b[0]&255)==239&&(b[1]&255)==187&&(b[2]&255)==191)return strict(b,3,StandardCharsets.UTF_8);
  if(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==254)return strict(b,2,StandardCharsets.UTF_16LE);
  if(b.length>=2&&(b[0]&255)==254&&(b[1]&255)==255)return strict(b,2,StandardCharsets.UTF_16BE);
  if(!encoding.equals("auto"))return strict(b,0,Charset.forName(encoding));
  int even=0,odd=0;for(int i=0;i<b.length;i++)if(b[i]==0){if(i%2==0)even++;else odd++;}
  if(b.length>=4&&b.length%2==0){if(odd>b.length/8&&even==0)return strict(b,0,StandardCharsets.UTF_16LE);if(even>b.length/8&&odd==0)return strict(b,0,StandardCharsets.UTF_16BE);}
  try{return strict(b,0,StandardCharsets.UTF_8);}catch(CharacterCodingException e){return strict(b,0,Charset.forName("windows-1251"));}
 }
 /** Only an explicit ISO-8601 creation header, never an inferred date. */
 public static long created(String body){int end=body.indexOf('\n');String line=(end<0?body:body.substring(0,end)).trim();if(!line.startsWith("Created: "))return 0;try{return java.time.OffsetDateTime.parse(line.substring(9).trim()).toInstant().toEpochMilli();}catch(java.time.DateTimeException ex){return 0;}}
 public static String[] split(String s,String delimiter){return delimiter.isEmpty()?new String[]{s}:s.split(Pattern.quote(delimiter),-1);}
 /** Recognize dated MyNotes exports only when both date header and divider are present. */
 public record Part(String body,long created){}
 private static final Pattern HEADER=Pattern.compile("(?iu)^[ \\t]*(\\d{1,2})[ \\t]+([\\p{L}.]+)[ \\t]+(\\d{4})(?:[ \\t]+[рг]\\.)?[ \\t]*\\r?\\n[ \\t]*[\\p{L}.’ʼ']+,?[ \\t]+(\\d{1,2}):(\\d{2})[ \\t]*\\r?(?:\\n|$)");
 private static final Pattern DIVIDER=Pattern.compile("(?m)^[ \\t]*(?:[-‐‑‒–—−─═_][ \\t]*){5,}[ \\t]*\\r?(?:\\n|$)");
 private static final String[][] MONTHS={{"січня","января","january"},{"лютого","февраля","february"},{"березня","марта","march"},{"квітня","апреля","april"},{"травня","мая","may"},{"червня","июня","june"},{"липня","июля","july"},{"серпня","августа","august"},{"вересня","сентября","september"},{"жовтня","октября","october"},{"листопада","ноября","november"},{"грудня","декабря","december"}};
 private static long headerDate(java.util.regex.Matcher m){try{int month=0;String v=m.group(2).toLowerCase(Locale.ROOT);for(int i=0;i<12;i++)for(String x:MONTHS[i])if(x.equals(v))month=i+1;if(month==0)return 0;return java.time.LocalDateTime.of(Integer.parseInt(m.group(3)),month,Integer.parseInt(m.group(1)),Integer.parseInt(m.group(4)),Integer.parseInt(m.group(5))).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();}catch(RuntimeException ex){return 0;}}
 public static List<Part> autoParts(String s){ArrayList<Part> out=new ArrayList<>();java.util.regex.Matcher first=HEADER.matcher(s);int start=0;while(start<s.length()&&Character.isWhitespace(s.charAt(start)))start++;first.region(start,s.length());if(!first.lookingAt())return Collections.singletonList(new Part(s,created(s)));long date=headerDate(first);if(date==0)return Collections.singletonList(new Part(s,created(s)));int bodyStart=first.end();java.util.regex.Matcher div=DIVIDER.matcher(s);int probe=bodyStart;while(div.find(probe)){int next=div.end();while(next<s.length()&&(s.charAt(next)=='\n'||s.charAt(next)=='\r'))next++;java.util.regex.Matcher h=HEADER.matcher(s);h.region(next,s.length());if(h.lookingAt()&&headerDate(h)!=0){out.add(new Part(s.substring(bodyStart,div.start()),date));date=headerDate(h);bodyStart=h.end();probe=bodyStart;}else probe=div.end();}if(out.isEmpty())return Collections.singletonList(new Part(s,created(s)));out.add(new Part(s.substring(bodyStart),date));return out;}
 public static List<Part> parts(String s,String mode,String delimiter){if(mode.equals("auto"))return autoParts(s);ArrayList<Part> out=new ArrayList<>();for(String p:split(s,mode.equals("manual")?delimiter:""))out.add(new Part(p,created(p)));return out;}
 public static boolean txt(String n){return n.toLowerCase(Locale.ROOT).endsWith(".txt");}
 public static String title(String n){n=n.replace('\\','/');n=n.substring(n.lastIndexOf('/')+1);return txt(n)?n.substring(0,n.length()-4):n;}
 public static final class Archive { public final List<Entry> files=new ArrayList<>();public int skipped; }
 public record Entry(String name,long modified,byte[] bytes){}
 public static Archive zip(InputStream stream,java.util.function.BooleanSupplier cancelled)throws IOException{
  Archive a=new Archive();int count=0,total=0;try(ZipInputStream z=new ZipInputStream(stream)){ZipEntry e;while((e=z.getNextEntry())!=null){if(cancelled.getAsBoolean())throw new InterruptedIOException();if(++count>MAX_ENTRIES)throw new IOException("Entry limit");if(e.isDirectory()){z.closeEntry();continue;}byte[] b=read(z,Math.min(MAX_FILE,MAX_TOTAL-total));total+=b.length;if(txt(e.getName()))a.files.add(new Entry(e.getName(),e.getTime(),b));else a.skipped++;z.closeEntry();}}if(count==0)throw new IOException("Empty or invalid ZIP");return a;
 }
}
