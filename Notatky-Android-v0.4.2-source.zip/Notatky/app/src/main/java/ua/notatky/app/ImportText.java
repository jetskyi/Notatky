package ua.notatky.app;
import java.io.*;import java.nio.*;import java.nio.charset.*;import java.util.*;import java.util.regex.Pattern;import java.util.zip.*;
/** Pure Java text decoding and bounded archive processing. */
public final class ImportText {
 public static final int MAX_FILE=16*1024*1024, MAX_TOTAL=64*1024*1024, MAX_ENTRIES=10000;
 public static byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(n>max-out.size())throw new IOException("Size limit");out.write(b,0,n);}return out.toByteArray();}
 static String strict(byte[] b,int offset,Charset c)throws CharacterCodingException{return c.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b,offset,b.length-offset)).toString();}
 public static String decode(byte[] b,String encoding)throws CharacterCodingException{
  if(b.length>=3&&(b[0]&255)==239&&(b[1]&255)==187&&(b[2]&255)==191)return strict(b,3,StandardCharsets.UTF_8);
  if(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==254)return strict(b,2,StandardCharsets.UTF_16LE);
  if(b.length>=2&&(b[0]&255)==254&&(b[1]&255)==255)return strict(b,2,StandardCharsets.UTF_16BE);
  if(!encoding.equals("auto"))return strict(b,0,Charset.forName(encoding));
  int even=0,odd=0;for(int i=0;i<b.length;i++)if(b[i]==0){if(i%2==0)even++;else odd++;}
  if(b.length>=4&&b.length%2==0){if(odd>b.length/8&&even==0)return strict(b,0,StandardCharsets.UTF_16LE);if(even>b.length/8&&odd==0)return strict(b,0,StandardCharsets.UTF_16BE);}
  try{return strict(b,0,StandardCharsets.UTF_8);}catch(CharacterCodingException e){return strict(b,0,Charset.forName("windows-1251"));}
 }
 /** Only an explicit ISO-8601 creation header, never an inferred date. */
 public static long created(String body){int end=body.indexOf('\n');String line=(end<0?body:body.substring(0,end)).trim();if(!line.startsWith("Created: "))return 0;try{return java.time.OffsetDateTime.parse(line.substring(9).trim()).toInstant().toEpochMilli();}catch(java.time.DateTimeException ex){return 0;}}
 public static String[] split(String s,String delimiter){return delimiter.isEmpty()?new String[]{s}:s.split(Pattern.quote(delimiter),-1);}
 /** Recognize dated MyNotes exports only when both date header and divider are present. */
 public record Part(String body,long created){}
 // Horizontal Unicode whitespace includes NBSP and narrow NBSP used by localized date formatters.
 private static final Pattern HEADER=Pattern.compile("(?iu)\\h*(\\d{1,2})\\h+([\\p{L}\\p{M}.]+)\\h+(\\d{4})(?:\\h*[рг]\\.?)?\\h*\\R(?:\\h*\\R)*\\h*[\\p{L}\\p{M}.’‘ʼ'`\\-]+\\h*[,，]?\\h+(\\d{1,2}):(\\d{2})(?::\\d{2})?\\h*(?:\\R|$)");
 private static final Pattern DIVIDER=Pattern.compile("(?m)^\\h*(?:[-‐‑‒–—−─═_]\\h*){5,}(?:\\R|$)");
 private static final Pattern BLANK=Pattern.compile("(?:\\h|\\R|\\uFEFF)*");
 private static final Pattern TITLE=Pattern.compile("(?iu)\\h*MyNotes(?:\\.txt)?\\h*\\R");
 private static final String[][] MONTHS={{"січня","января","january"},{"лютого","февраля","february"},{"березня","марта","march"},{"квітня","апреля","april"},{"травня","мая","may"},{"червня","июня","june"},{"липня","июля","july"},{"серпня","августа","august"},{"вересня","сентября","september"},{"жовтня","октября","october"},{"листопада","ноября","november"},{"грудня","декабря","december"}};
 private static long headerDate(java.util.regex.Matcher m){try{int month=0;String v=m.group(2).toLowerCase(Locale.ROOT);for(int i=0;i<12;i++)for(String x:MONTHS[i])if(x.equals(v))month=i+1;if(month==0)return 0;return java.time.LocalDateTime.of(Integer.parseInt(m.group(3)),month,Integer.parseInt(m.group(1)),Integer.parseInt(m.group(4)),Integer.parseInt(m.group(5))).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();}catch(RuntimeException ex){return 0;}}
 private static int skipBlank(String s,int at){var m=BLANK.matcher(s);m.region(at,s.length());m.lookingAt();return m.end();}
 private static java.util.regex.Matcher header(String s,int at){var m=HEADER.matcher(s);m.region(at,s.length());return m;}
 public static List<Part> autoParts(String s){
  ArrayList<Part> out=new ArrayList<>();int start=skipBlank(s,0);var title=TITLE.matcher(s);title.region(start,s.length());if(title.lookingAt())start=skipBlank(s,title.end());
  var first=header(s,start);if(!first.lookingAt())return Collections.singletonList(new Part(s,created(s)));long date=headerDate(first);if(date==0)return Collections.singletonList(new Part(s,created(s)));
  int bodyStart=first.end();var div=DIVIDER.matcher(s);int probe=bodyStart;
  while(div.find(probe)){int next=skipBlank(s,div.end());var h=header(s,next);if(h.lookingAt()&&headerDate(h)!=0){out.add(new Part(s.substring(bodyStart,div.start()),date));date=headerDate(h);bodyStart=h.end();probe=bodyStart;}else probe=div.end();}
  if(out.isEmpty())return Collections.singletonList(new Part(s,created(s)));out.add(new Part(s.substring(bodyStart),date));return out;
 }
 /** A known multi-note export must never silently fall back to a single note. */
 public static List<Part> myNotesParts(String s)throws IOException{
  var out=autoParts(s);if(out.size()>1)return out;
  int start=skipBlank(s,0);var t=TITLE.matcher(s);t.region(start,s.length());if(t.lookingAt())start=skipBlank(s,t.end());var h=header(s,start);
  if(h.lookingAt()&&headerDate(h)!=0){var div=DIVIDER.matcher(s);if(!div.find(h.end()))return Collections.singletonList(new Part(s.substring(h.end()),headerDate(h)));}
  throw new IOException("Unrecognized MyNotes export boundaries");
 }
 public static List<Part> parts(String s,String mode,String delimiter){if(mode.equals("auto"))return autoParts(s);ArrayList<Part> out=new ArrayList<>();for(String p:split(s,mode.equals("manual")?delimiter:""))out.add(new Part(p,created(p)));return out;}
 public static boolean isMyNotesName(String name){return title(name).matches("(?i)MyNotes(?:[ _-]*\\(?[0-9]+\\)?)?");}
 public static boolean txt(String n){return n.toLowerCase(Locale.ROOT).endsWith(".txt");}
 public static String title(String n){n=n.replace('\\','/');n=n.substring(n.lastIndexOf('/')+1);return txt(n)?n.substring(0,n.length()-4):n;}
 public static final class Archive { public final List<Entry> files=new ArrayList<>();public int skipped; }
 public record Entry(String name,long modified,byte[] bytes){}
 public static Archive zip(InputStream stream,java.util.function.BooleanSupplier cancelled)throws IOException{
  Archive a=new Archive();int count=0,total=0;try(ZipInputStream z=new ZipInputStream(stream)){ZipEntry e;while((e=z.getNextEntry())!=null){if(cancelled.getAsBoolean())throw new InterruptedIOException();if(++count>MAX_ENTRIES)throw new IOException("Entry limit");if(e.isDirectory()){z.closeEntry();continue;}byte[] b=read(z,Math.min(MAX_FILE,MAX_TOTAL-total));total+=b.length;if(txt(e.getName()))a.files.add(new Entry(e.getName(),e.getTime(),b));else a.skipped++;z.closeEntry();}}if(count==0)throw new IOException("Empty or invalid ZIP");return a;
 }
}
