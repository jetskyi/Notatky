package ua.notatky.app;import android.content.*;public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){ReminderReceiver.all(c);}}
