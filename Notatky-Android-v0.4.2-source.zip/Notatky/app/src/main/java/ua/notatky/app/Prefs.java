package ua.notatky.app;
import android.content.*;import android.content.res.Configuration;import java.util.Locale;
final class Prefs {
 static String get(Context c,String k,String def){return c.getSharedPreferences("preferences",0).getString(k,def);}
 static void set(Context c,String k,String v){c.getSharedPreferences("preferences",0).edit().putString(k,v).commit();}
 static Context localized(Context c){Configuration cfg=new Configuration();cfg.setLocale(Locale.forLanguageTag(get(c,"language","uk")));return c.createConfigurationContext(cfg);}
 static boolean dark(Context c){String v=get(c,"theme","system");return v.equals("dark")||v.equals("system")&&(c.getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;}
}
