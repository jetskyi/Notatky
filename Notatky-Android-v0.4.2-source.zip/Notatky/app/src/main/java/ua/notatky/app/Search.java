package ua.notatky.app;
import java.util.*;
import java.util.regex.*;
import java.text.Normalizer;
public final class Search {
 public record Hit(int start,int end,int score) {}
 static String norm(String s){return Normalizer.normalize(s.toLowerCase(Locale.ROOT).replace('ё','е'),Normalizer.Form.NFC);}
 static final Pattern WORD=Pattern.compile("[\\p{L}\\p{N}]+");
 static List<String> words(String s){var a=new ArrayList<String>();var m=WORD.matcher(norm(s));while(m.find())a.add(m.group());return a;}
 static int dist(String a,String b){int[] p=new int[b.length()+1],c=new int[b.length()+1];for(int j=0;j<p.length;j++)p[j]=j;for(int i=1;i<=a.length();i++){c[0]=i;for(int j=1;j<=b.length();j++)c[j]=Math.min(Math.min(c[j-1]+1,p[j]+1),p[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));int[] t=p;p=c;c=t;}return p[b.length()];}
 static String stem(String s){return s.replaceFirst("(ого|ому|ыми|ими|ая|яя|ый|ий|ой|ые|ие|аря|ів|ами|ями|en|er|es|ing|ed)$","");}
 static int similarity(String a,String b){if(a.equals(b))return 100;if(a.length()>=3&&b.startsWith(a))return 85;String x=stem(a),y=stem(b);if(x.length()>=3&&x.equals(y))return 82;int n=Math.max(a.length(),b.length());if(n<4||Math.abs(a.length()-b.length())>3)return 0;int d=dist(a,b);return d<=Math.max(1,n/3)?70-d*5:0;}
 public static List<Hit> find(String text,String query,boolean fuzzy){var out=new ArrayList<Hit>();if(query.trim().isEmpty())return out;String q=norm(query.trim());var exact=Pattern.compile(Pattern.quote(query.trim().replace('ё','е').replace('Ё','Е')),Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(text.replace('ё','е').replace('Ё','Е'));while(exact.find())out.add(new Hit(exact.start(),exact.end(),100));if(!fuzzy)return out;var qs=words(q);if(qs.isEmpty())return out;var m=Pattern.compile("[^\\r\\n]+").matcher(text);while(m.find()){String line=m.group();var ws=words(line);int sum=0;boolean ok=true;for(String w:qs){int best=0;for(String v:ws){best=Math.max(best,similarity(w,v));if(best==100)break;}if(best==0){ok=false;break;}sum+=best;}if(ok){boolean overlap=false;for(Hit h:out)if(h.start>=m.start()&&h.start<m.end()){overlap=true;break;}if(!overlap)out.add(new Hit(m.start(),m.end(),Math.min(99,sum/qs.size())));}}out.sort(Comparator.comparingInt(Hit::score).reversed().thenComparingInt(Hit::start));return out;}
}
