package ua.notatky.app;
import java.nio.file.*;import java.time.*;import java.security.*;import java.nio.charset.StandardCharsets;import java.util.*;
/** Optional test against a user's local export. Never bundle private source data. */
public class RealExportTest {
 public static void main(String[] args)throws Exception{
  var parts=ImportText.myNotesParts(ImportText.decode(Files.readAllBytes(Path.of(args[0])),"auto"));
  MessageDigest digest=MessageDigest.getInstance("SHA-256");
  for(var p:parts){String hash=HexFormat.of().formatHex(digest.digest(p.body().getBytes(StandardCharsets.UTF_8)));System.out.println(p.created()+"\t"+hash);}
 }
}
