package ua.notatky.app;
import java.time.*;
public class MyNotesRegressionTest {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);System.out.println("PASS "+s);}
 public static void main(String[] args)throws Exception {
 String a="13\u00a0листопада\u00a02026\u202fр.\r\nП’ятниця,\u00a022:24\r\n\r\nПерша 😀\r\n\r\n", b="15 жовтня 2026\u00a0р.\r\nЧетвер, 17:34\r\n\r\nДруга\r\n\r\n", c="25 вересня 2026 р.\r\nП’ятниця, 20:49\r\n\r\nТретя";
 String export=a+"- - - - - - - - - -\r\n\r\n"+b+"-\u00a0-\u00a0-\u00a0-\u00a0-\r\n\r\n"+c;
 var p=ImportText.myNotesParts(export);check(p.size()==3,"localized NBSP/narrow NBSP, CRLF and spaced dividers");
 check(p.get(0).body().equals("\r\nПерша 😀\r\n\r\n"),"body preserved");
 check(p.get(1).created()==LocalDateTime.of(2026,10,15,17,34).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),"October date restored");
 check(p.get(2).created()==LocalDateTime.of(2026,9,25,20,49).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),"September date restored");
 check(ImportText.myNotesParts("\uFEFFMyNotes.txt\n\n"+export).size()==3,"optional export heading and BOM");
 check(ImportText.myNotesParts(a.replace("р.\r\n", "р.\r\n\r\n")+"-----\r\n"+b).size()==2,"blank line in metadata");
 try{ImportText.myNotesParts("unrecognized\n-----\nsecond");throw new AssertionError();}catch(java.io.IOException e){check(true,"unrecognized MyNotes refused, no silent merge");}
 check(ImportText.myNotesParts(a).size()==1,"one valid dated entry");
 }
}
